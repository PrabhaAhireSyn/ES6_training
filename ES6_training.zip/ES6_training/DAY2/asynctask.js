function makeAPromise() {
    //should return object of promise

    return new Promise(function(resolve, reject) {
        var requestObj = new XMLHttpRequest();
            requestObj.open('GET', 'https://jsonplaceholder.typicode.com/postss', true);
            requestObj.send();

            requestObj.onreadystatechange = function() {
                if (requestObj.readyState == 4 && requestObj.status == 200) {
                    resolve(requestObj.responseText);
                } else if (requestObj.readyState == 4 && requestObj.status != 200) {
                    reject(requestObj.statusText);
                }
            }
    });
}