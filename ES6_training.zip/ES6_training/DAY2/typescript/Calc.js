"use strict";
exports.__esModule = true;
var math_1 = require("./math");
console.log(math_1.Add(20, 30));
console.log(math_1["default"]);
var arr = [1, 2, 3];
console.log(arr);
arr[3] = 2;
console.log(arr);
