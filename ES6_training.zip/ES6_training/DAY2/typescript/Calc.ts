import Pie, {Add} from './math';

console.log(Add(20,30));
console.log(Pie);

const arr = [1,2,3];
console.log(arr);
arr[3] = 2;
console.log(arr);