//let x = 100;
//x= 'hello'; //Type inference
var str; //Type annotation
var i;
var b;
var o;
o = 10000;
o = 'bye';
o = { name: 'ányType' };
o = [10, 20, 30];
console.log(o);
var aVariableWithoutType; //datatype any will be assigned
//Parameter default datatype is 'any'
function Add(x, y) {
    return x + y;
}
//Can specify parameter datatype
function Add(x, y) {
    return x + y;
}
//Can assign return type of function
function Add(x, y) {
    return x + y;
}
