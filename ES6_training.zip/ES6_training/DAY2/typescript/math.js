"use strict";
exports.__esModule = true;
function Add(x, y) {
    return x + y;
}
exports.Add = Add;
function Product(x, y) {
    return x * y;
}
exports.Product = Product;
//Default export option, only one variable/function/object, etc. can be exported by default.
//See import option for PI in Calc.ts
var PI = 3.14;
exports["default"] = PI;
