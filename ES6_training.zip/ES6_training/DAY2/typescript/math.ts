export function Add(x, y) {
    return x+y;
}

export function Product(x, y) {
    return x*y;
}

//Default export option, only one variable/function/object, etc. can be exported by default.
//See import option for PI in Calc.ts
const PI = 3.14;
export default PI;